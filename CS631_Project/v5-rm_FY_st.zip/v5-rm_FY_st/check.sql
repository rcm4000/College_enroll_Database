﻿select s.CR_ID from Register rg inner join Section AS s on s.[S.Number] = rg.[S.Number] and rg.S_ID = 3

select * from Register
where S_ID = 3

select [S.Number] from Register where S_ID = 3