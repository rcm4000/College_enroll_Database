﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace v5_rm_FY_st
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void stubutton_Click(object sender, EventArgs e)
        {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
                String stu = stubox.Text;
                String pass = passbox.Text;
               
                string checkuser = "select count(*) from Student where CONVERT(VARCHAR,[S_Id])='" + stu + "'and CONVERT(VARCHAR,[Password])='" + pass + "'";
                int i = 0;
               SqlCommand com = new SqlCommand(checkuser, conn);
                conn.Open();
                Session["User"] = stubox.Text;
                i = (int)com.ExecuteScalar();
            conn.Close();
            if (i > 0)
            {
                Session["User"] = stubox.Text;
                Response.Redirect("st_loggedIn.aspx");
            }   
            else
                Label4.Text = "Invalid Credentials";
                Session.RemoveAll();
            }
    }
    }
 
    
