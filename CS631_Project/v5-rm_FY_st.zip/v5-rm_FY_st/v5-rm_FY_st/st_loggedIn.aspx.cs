﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Text;
using System.Threading.Tasks;


namespace v5_rm_FY_st
{
    public partial class st_loggedIn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //  Get user session information from Login page
            if (Session["User"] == null)
            {
                Response.Redirect("default.asp");  // if login info is wrong redirect to mainpage
            }

            else
            {

                // Print User ID on student login Page and connect to database to load user Ddata and classes
                welcome1.Text = Session["User"].ToString();
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

            }
        }


        protected void GridView2_SelectedIndexChanged1(object sender, EventArgs e)
        {

            // Get the currently selected row using the SelectedRow property.
            GridViewRow row = GridView2.SelectedRow;

            

            // Query database:


            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
            conn.Open();
            SqlCommand totalrg = new SqlCommand("SELECT COUNT([S.Number]) FROM Register WHERE S_ID = '" + welcome1.Text + "'", conn);
            int i = (int)totalrg.ExecuteScalar();

            SqlCommand getcrs = new SqlCommand("Select * from Student_Courselist WHERE S_ID = '" + welcome1.Text + "' and Section ='" + row.Cells[3].Text + "'", conn);
            SqlDataAdapter stlist = new SqlDataAdapter(getcrs);
            DataTable stl = new DataTable();
            stlist.Fill(stl);
            if (stl.Rows.Count == 0)
            {
                if (i >= 4)
                {
                    Labelerror1.Text = "You are only allowed to take 4 classes per semester.  Please remove a class to add this class or see an adviser.";
                }
                else if (Convert.ToInt16(row.Cells[7].Text) < Convert.ToInt16(row.Cells[8].Text) + 1)
                {
                    Labelerror1.Text = "The class is full";

                }
                else
                {
                    System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "INSERT [Register] (S_ID, [S.Number]) VALUES ('" + welcome1.Text + "','" + row.Cells[3].Text + "')";
                    SqlConnection conn1 = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
                    conn1.Open();
                    SqlCommand cmd1 = new SqlCommand(cmd.CommandText, conn1);
                    cmd1.ExecuteNonQuery();
                    conn1.Close();
                    Response.Redirect(Request.RawUrl);
                    Labelerror1.Text = "You were successfully enrolled.";
                }
            }
            else
            {
                string crs1 = stl.Rows[0]["Course ID"].ToString(); // course
                string sect = stl.Rows[0]["Section"].ToString(); // course

                //SqlCommand cmd = new SqlCommand("", conn);



                courseLabe2.Text = row.Cells[3].Text;  // Section
                courseLabe1.Text = row.Cells[1].Text;  // Course
                courseLabe7.Text = row.Cells[7].Text;  // Capacity
                courseLabe8.Text = row.Cells[8].Text;  // Students in class



                regmess.Text = "Registration Notification";
                coursemessageLabel0.Text = "You are attempting to register for the class below.  Please confirm your request.";
                coursemessageLabel.Text = "Course: " + row.Cells[1].Text + "";
                coursemessageLabe2.Text = "Section: " + row.Cells[3].Text + ".";
                coursemessageLabe3.Text = "Time: " + row.Cells[4].Text + ".";
                coursemessageLabe4.Text = "Meets on: " + row.Cells[5].Text + ".";
                coursemessageLabe5.Text = "Instructor: " + row.Cells[6].Text + ".";
                coursemessageLabe6.Text = "Capacity: " + row.Cells[7].Text + ".";
                coursemessageLabe7.Text = "Students In class: " + row.Cells[8].Text + ".";

               
                
                
                

                if (i >= 4)
                {
                    Labelerror1.Text = "You are only allowed to take 4 classes per semester.  Please remove a class to add this class or see an adviser.";
                }
                else if (crs1 == courseLabe1.Text)
                {
                    Labelerror1.Text = "You are already registered for this course";
                }

                else if (sect == courseLabe2.Text)
                {
                    Labelerror1.Text = "You are already registered for this section";
                }

                else if (Convert.ToInt16(row.Cells[7].Text) < Convert.ToInt16(row.Cells[8].Text) + 1)
                {
                    Labelerror1.Text = "The class is full";

                }
                else
                {
                    System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "INSERT [Register] (S_ID, [S.Number]) VALUES ('" + welcome1.Text + "','" + courseLabe2.Text + "')";
                    SqlConnection conn1 = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
                    conn1.Open();
                    SqlCommand cmd1 = new SqlCommand(cmd.CommandText, conn1);
                    cmd1.ExecuteNonQuery();
                    conn1.Close();
                    Response.Redirect(Request.RawUrl);
                    Labelerror1.Text = "You were successfully enrolled.";

                }

            }



        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("default.aspx");
        }


    }
}