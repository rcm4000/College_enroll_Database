﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace v5_rm_FY_st
{
    public partial class _adminlg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
                
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
            String emp = empbox0.Text;
            String pass2 = passbox2.Text;

            string checkadmin = "select count(*) from STAFF where Staff_Type = 'ADMIN' and CONVERT(VARCHAR,[SSN])='" + emp + "'and CONVERT(VARCHAR,[Passwd])='" + pass2 + "'";

            int j = 0;
            SqlCommand com = new SqlCommand(checkadmin, conn);
            conn.Open();
            Session["Emp"] = empbox0.Text;
            j = (int)com.ExecuteScalar();
            conn.Close();
            if (j > 0)
            {
                Session["Emp"] = empbox0.Text;
                Response.Redirect("adminrp.aspx");
            }
            else
                Label5.Text = "Invalid Credentials";
            Session.RemoveAll();
        }
    }
    }
