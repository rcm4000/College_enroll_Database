﻿Select Fac_SSN, count ([S.Number])
from Section 
group by Fac_SSN


Create Table Teaching_Assistant
([TA_SSN] INT NOT NULL,
  F_p_time Char,
  W_hours int not null
  PRIMARY KEY CLUSTERED ([TA_SSN] ASC),
  FOREIGN KEY ([TA_SSN]) REFERENCES [dbo].[STAFF] ([SSN])
  
  )

  Alter table Faculty
  add Constraint checkfac 
  check select Fac_SSN from Faculty where Fac_SSN in ( Select SSN from STAFF where Staff_Type = 'Faculty');