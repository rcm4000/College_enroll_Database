﻿Alter table Courses 
add foreign key ([D.code]) references Department([D.Code]);

Alter table Register
add foreign key (S_ID) references dbo.Student(S_ID);

Alter table Register
add foreign key ([S.Number]) references Section([S.Number]);

Alter table Section
add Foreign key (CR_ID) references Courses(CR_ID);

Alter table Section
add Foreign key (TIMEID) references [Time](TIMEID);



Create table Rooms
( [Room_ID]  VARCHAR (10) NOT NULL,
  [Capacity] INT          NOT NULL,
  [Audio_VIS_Equip] VARCHAR (10) NOT NULL,
  [B.ID]     INT        NOT NULL,
  PRIMARY KEY CLUSTERED ([Room_ID] ASC)
  )
Alter table Section
add foreign key(Room_ID) references Rooms(Room_ID);

Create table Faculty
([Fac_SSN]        INT          NOT NULL,
 [C.load] int not null,
 [Max.H] int not Null,
 [Rank] int not null
 PRIMARY KEY CLUSTERED ([Fac_SSN] ASC)
 foreign key (Fac_SSN) references Staff(SSN)
 )

Alter table Section
add foreign key(Fac_SSN) references STAFF(SSN);
 